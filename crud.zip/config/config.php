<?php
return [
    'db' => [
        'dsn' => 'sqlite:' . __DIR__ . '/../database.sqlite',
        // For MySQL: 'mysql:host=localhost;dbname=crud;charset=utf8mb4'
        'user' => '',
        'pass' => '',
    ],
];
