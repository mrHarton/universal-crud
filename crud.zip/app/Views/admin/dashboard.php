<h1>Admin Dashboard</h1>
<p>Добро пожаловать, администратор!</p>

<ul>
    <li><a href="/admin/collections">Посмотреть коллекции</a></li>
    <li><a href="/admin/create">Создать коллекцию</a></li>
</ul>
