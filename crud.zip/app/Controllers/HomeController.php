<?php

class HomeController
{
    public function index()
    {
        echo "Welcome to Universal CRUD!";
    }
}
